package tqs.cars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsCarsContainersApplication {

    public static void main(String[] args) {
        SpringApplication.run(GsCarsContainersApplication.class, args);
    }

}
